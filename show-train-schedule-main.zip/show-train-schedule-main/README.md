# show-train-schedule
1. Please clone code
2. Go to the directory where test server is present
3. run ```go mod tidy```
4. run ```go run *.go```
